#ifndef __MOTE_H__
#define __MOTE_H__

#define MAX_MOTES 4

uint8_t version = 3;

#endif
